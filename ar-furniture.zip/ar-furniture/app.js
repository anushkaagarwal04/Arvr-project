import * as THREE from 'three';
import { OrbitControls } from './vendor/OrbitControls.js';
import { CATALOG, buildItem } from './furniture.js';

const $ = s => document.querySelector(s);
const canvas = $('#scene'), ui = $('#ui');
const statusEl = $('#status'), hintEl = $('#hint');
const arBtn = $('#ar-btn'), exitBtn = $('#exit-btn');
const SWATCHES = ['#7a8b6f', '#c9b79c', '#3d4a5c', '#b5533c', '#2b2b2b', '#e8e2d6', '#a9784f', '#d9a441'];

// ---------- renderer / scene ----------
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.xr.enabled = true;

const scene = new THREE.Scene();
const PREVIEW_BG = new THREE.Color('#2a302d');
scene.background = PREVIEW_BG;
const camera = new THREE.PerspectiveCamera(55, 1, 0.05, 50);
camera.position.set(2.6, 2.2, 3.2);

scene.add(new THREE.HemisphereLight(0xffffff, 0x6b6b60, 1.1));
const sun = new THREE.DirectionalLight(0xffffff, 1.4);
sun.position.set(1.5, 4, 1.5);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
Object.assign(sun.shadow.camera, { left: -2.5, right: 2.5, top: 2.5, bottom: -2.5, near: 0.5, far: 10 });
sun.shadow.bias = -0.0005;
scene.add(sun, sun.target);

// Preview floor (hidden in AR) + shadow catcher (used in both)
const grid = new THREE.GridHelper(10, 20, 0x56605a, 0x3b4440);
const floor = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshStandardMaterial({ color: '#343b37', roughness: 1 }));
floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true;
const previewGroup = new THREE.Group(); previewGroup.add(floor, grid); scene.add(previewGroup);

const catcher = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), new THREE.ShadowMaterial({ opacity: 0.35 }));
catcher.rotation.x = -Math.PI / 2; catcher.receiveShadow = true; catcher.visible = false; scene.add(catcher);

const controls = new OrbitControls(camera, canvas);
controls.target.set(0, 0.5, 0); controls.enableDamping = true; controls.maxPolarAngle = Math.PI / 2.05;

// Selection ring
const ring = new THREE.Mesh(new THREE.RingGeometry(0.5, 0.53, 48), new THREE.MeshBasicMaterial({ color: 0x9fd3b4, side: THREE.DoubleSide, depthTest: false, transparent: true, opacity: .9 }));
ring.rotation.x = -Math.PI / 2; ring.position.y = 0.005; ring.renderOrder = 10; ring.visible = false;

// AR reticle
const reticle = new THREE.Mesh(
  new THREE.RingGeometry(0.12, 0.15, 40).rotateX(-Math.PI / 2),
  new THREE.MeshBasicMaterial({ color: 0xffffff }));
reticle.matrixAutoUpdate = false; reticle.visible = false; scene.add(reticle);

// ---------- state ----------
const items = [];
let selected = null, currentType = CATALOG[0].id, moveMode = false, color = null;

function setHint(t, ms = 0) { hintEl.textContent = t; if (ms) setTimeout(() => { if (hintEl.textContent === t) hintEl.textContent = ''; }, ms); }

function select(item) {
  selected = item;
  document.body.classList.toggle('has-sel', !!item);
  ring.visible = !!item;
  if (item) {
    const [w, h, d] = item.userData.dims, r = Math.max(w, d) / 2 * 1.15;
    item.add(ring); ring.scale.setScalar(r / 0.5);
    ring.scale.y = ring.scale.z = ring.scale.x;
    $('#info').hidden = false;
    $('#info-name').textContent = item.userData.name;
    updateDims();
    document.querySelectorAll('.sw').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.c === '#' + item.userData.tint.color.getHexString())));
  } else { ring.removeFromParent(); $('#info').hidden = true; }
}
function updateDims() {
  if (!selected) return;
  const s = selected.scale.x, [w, h, d] = selected.userData.dims.map(v => Math.round(v * s * 100));
  $('#info-dims').textContent = `${w} × ${d} × ${h} cm (W × D × H)`;
}

function place(pos, yaw) {
  const item = buildItem(currentType, color);
  item.position.copy(pos); item.rotation.y = yaw;
  scene.add(item); items.push(item);
  sun.target.position.copy(pos); sun.position.set(pos.x + 1.5, pos.y + 4, pos.z + 1.5);
  catcher.position.y = pos.y + 0.001; catcher.position.x = pos.x; catcher.position.z = pos.z;
  select(item); moveMode = false; setMove(false);
}
function moveSelected(pos) { if (selected) { selected.position.copy(pos); sun.target.position.copy(pos); sun.position.set(pos.x + 1.5, pos.y + 4, pos.z + 1.5); } }
function remove(item) {
  const i = items.indexOf(item); if (i < 0) return;
  items.splice(i, 1); if (selected === item) select(null); item.removeFromParent();
  item.traverse(o => { o.geometry?.dispose(); });
}
function pickItem(raycaster) {
  const hits = raycaster.intersectObjects(items, true);
  if (!hits.length) return null;
  let o = hits[0].object; while (o && !items.includes(o)) o = o.parent; return o;
}
function setMove(on) { moveMode = on; const b = $('#move-btn'); b.setAttribute('aria-pressed', String(on)); }

// ---------- UI wiring ----------
const catalogEl = $('#catalog');
CATALOG.forEach(c => {
  const b = document.createElement('button');
  b.setAttribute('role', 'option'); b.dataset.id = c.id;
  b.innerHTML = `<span class="chip-dot" style="background:${c.color}"></span>${c.name}`;
  b.onclick = () => { currentType = c.id; color = null; refreshCatalog(); setHint(inAR ? `Aim at the floor, then tap to place a ${c.name.toLowerCase()}` : `Click the floor to place a ${c.name.toLowerCase()}`, 3000); };
  catalogEl.appendChild(b);
});
function refreshCatalog() { catalogEl.querySelectorAll('button').forEach(b => b.setAttribute('aria-selected', String(b.dataset.id === currentType))); }
refreshCatalog();

SWATCHES.forEach(c => {
  const b = document.createElement('button');
  b.className = 'sw'; b.dataset.c = c; b.style.background = c; b.setAttribute('aria-label', 'Colour ' + c); b.setAttribute('aria-pressed', 'false');
  b.onclick = () => { color = c; if (selected) { selected.userData.tint.color.set(c); select(selected); } };
  $('#swatches').appendChild(b);
});

$('#actions').addEventListener('click', e => {
  const act = e.target.closest('button')?.dataset.act; if (!act) return;
  if (act === 'delete') return selected && remove(selected);
  if (act === 'move') { if (selected) { setMove(!moveMode); setHint(moveMode ? (inAR ? 'Tap the floor to move it there' : 'Click the floor to move it there') : '', 3000); } return; }
  if (!selected) return;
  if (act === 'left') selected.rotation.y += Math.PI / 12;
  if (act === 'right') selected.rotation.y -= Math.PI / 12;
  if (act === 'bigger') selected.scale.multiplyScalar(1.08);
  if (act === 'smaller') selected.scale.multiplyScalar(1 / 1.08);
  updateDims();
});
ui.addEventListener('beforexrselect', e => e.preventDefault());

// ---------- desktop / non-AR preview interaction ----------
const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), floorPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
let down = null;
canvas.addEventListener('pointerdown', e => { down = [e.clientX, e.clientY]; });
canvas.addEventListener('pointerup', e => {
  if (inAR || !down || Math.hypot(e.clientX - down[0], e.clientY - down[1]) > 6) return;
  ndc.set(e.clientX / innerWidth * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
  ray.setFromCamera(ndc, camera);
  const hit = pickItem(ray);
  if (hit && !moveMode) return select(hit);
  const p = new THREE.Vector3();
  if (!ray.ray.intersectPlane(floorPlane, p)) return;
  if (moveMode && selected) { moveSelected(p); setMove(false); }
  else place(p, Math.atan2(camera.position.x - p.x, camera.position.z - p.z));
});

// ---------- AR ----------
let inAR = false, hitSource = null, session = null;
const controller = renderer.xr.getController(0); scene.add(controller);
const tmpM = new THREE.Matrix4(), _p = new THREE.Vector3(), _c = new THREE.Vector3();

controller.addEventListener('select', () => {
  tmpM.identity().extractRotation(controller.matrixWorld);
  ray.ray.origin.setFromMatrixPosition(controller.matrixWorld);
  ray.ray.direction.set(0, 0, -1).applyMatrix4(tmpM);
  const hit = pickItem(ray);
  if (hit && !moveMode) { select(hit); return; }
  if (!reticle.visible) { setHint('Move your phone slowly to find the floor', 2500); return; }
  _p.setFromMatrixPosition(reticle.matrix);
  if (moveMode && selected) { moveSelected(_p); setMove(false); return; }
  renderer.xr.getCamera().getWorldPosition(_c);
  place(_p.clone(), Math.atan2(_c.x - _p.x, _c.z - _p.z));
  setHint('Placed. Use the buttons to rotate, resize or recolour.', 3000);
});

async function startAR() {
  try {
    session = await navigator.xr.requestSession('immersive-ar', {
      requiredFeatures: ['hit-test'],
      optionalFeatures: ['dom-overlay', 'local-floor'],
      domOverlay: { root: ui }
    });
  } catch (err) { setHint('Could not start AR: ' + err.message, 5000); return; }
  await renderer.xr.setSession(session);
  const viewer = await session.requestReferenceSpace('viewer');
  hitSource = await session.requestHitTestSource({ space: viewer });
  inAR = true; document.body.classList.add('ar');
  scene.background = null; previewGroup.visible = false; catcher.visible = true; controls.enabled = false;
  arBtn.hidden = true; exitBtn.hidden = false; statusEl.textContent = 'AR on';
  setHint('Scan the floor slowly, then tap to place', 4000);
  session.addEventListener('end', endAR);
}
function endAR() {
  hitSource?.cancel(); hitSource = null; session = null; inAR = false; reticle.visible = false;
  document.body.classList.remove('ar'); scene.background = PREVIEW_BG;
  previewGroup.visible = true; catcher.visible = false; controls.enabled = true;
  arBtn.hidden = false; exitBtn.hidden = true; statusEl.textContent = '3D preview';
}
arBtn.onclick = startAR; exitBtn.onclick = () => session?.end();

(async () => {
  let ok = false;
  try { ok = !!navigator.xr && await navigator.xr.isSessionSupported('immersive-ar'); } catch {}
  if (ok) { arBtn.hidden = false; statusEl.textContent = 'AR ready'; setHint('Tap Start AR, or try the 3D preview below', 4000); }
  else { statusEl.textContent = '3D preview'; setHint(window.isSecureContext ? 'AR needs Chrome on an ARCore Android phone. Place items on the grid.' : 'AR needs HTTPS. Place items on the grid.', 6000); }
})();

// ---------- loop ----------
function resize() {
  if (inAR) return;
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

renderer.setAnimationLoop((t, frame) => {
  if (frame && hitSource) {
    const ref = renderer.xr.getReferenceSpace(), hits = frame.getHitTestResults(hitSource);
    if (hits.length) { reticle.visible = true; reticle.matrix.fromArray(hits[0].getPose(ref).transform.matrix); }
    else reticle.visible = false;
  }
  if (!inAR) controls.update();
  renderer.render(scene, camera);
});
