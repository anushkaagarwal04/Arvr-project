import * as THREE from 'three';

const mat = (c, r = 0.75, m = 0) => new THREE.MeshStandardMaterial({ color: c, roughness: r, metalness: m });
function box(g, w, h, d, m, x, y, z) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.position.set(x, y + h / 2, z);
  mesh.castShadow = mesh.receiveShadow = true;
  g.add(mesh); return mesh;
}
function cyl(g, rt, rb, h, m, x, y, z, seg = 28) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb, h, seg), m);
  mesh.position.set(x, y + h / 2, z);
  mesh.castShadow = mesh.receiveShadow = true;
  g.add(mesh); return mesh;
}
function ball(g, r, m, x, y, z) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(r, 20, 16), m);
  mesh.position.set(x, y, z); mesh.castShadow = true; g.add(mesh); return mesh;
}
// Each builder returns a Group whose front faces +Z and base sits on y = 0.
// userData.tint is the material users can recolor.
const wood = () => mat('#a9784f', 0.6);
const dark = () => mat('#2c2a28', 0.5, 0.4);

const builders = {
  sofa(tint) {
    const g = new THREE.Group(), legs = dark();
    box(g, 2.0, 0.3, 0.9, tint, 0, 0.12, 0);
    box(g, 2.0, 0.5, 0.22, tint, 0, 0.3, -0.34);
    box(g, 0.22, 0.28, 0.9, tint, -0.89, 0.3, 0);
    box(g, 0.22, 0.28, 0.9, tint, 0.89, 0.3, 0);
    for (const x of [-0.45, 0.45]) box(g, 0.78, 0.14, 0.62, tint, x, 0.42, 0.06);
    for (const x of [-0.9, 0.9]) for (const z of [-0.38, 0.38]) cyl(g, 0.03, 0.025, 0.12, legs, x, 0, z, 10);
    return g;
  },
  armchair(tint) {
    const g = new THREE.Group(), legs = dark();
    box(g, 0.8, 0.28, 0.8, tint, 0, 0.14, 0);
    box(g, 0.8, 0.5, 0.18, tint, 0, 0.3, -0.31);
    box(g, 0.16, 0.25, 0.8, tint, -0.32, 0.3, 0.02);
    box(g, 0.16, 0.25, 0.8, tint, 0.32, 0.3, 0.02);
    box(g, 0.48, 0.12, 0.55, tint, 0, 0.42, 0.08);
    for (const x of [-0.33, 0.33]) for (const z of [-0.33, 0.33]) cyl(g, 0.03, 0.025, 0.14, legs, x, 0, z, 10);
    return g;
  },
  dining_table(tint) {
    const g = new THREE.Group();
    box(g, 1.6, 0.05, 0.9, tint, 0, 0.7, 0);
    for (const x of [-0.72, 0.72]) for (const z of [-0.37, 0.37]) box(g, 0.07, 0.7, 0.07, tint, x, 0, z);
    return g;
  },
  chair(tint) {
    const g = new THREE.Group(), seat = mat('#d8d0c0', 0.9);
    box(g, 0.44, 0.04, 0.44, tint, 0, 0.44, 0);
    box(g, 0.44, 0.4, 0.04, tint, 0, 0.5, -0.2);
    for (const x of [-0.19, 0.19]) for (const z of [-0.19, 0.19]) box(g, 0.04, 0.44, 0.04, tint, x, 0, z);
    box(g, 0.38, 0.03, 0.38, seat, 0, 0.48, 0.01);
    return g;
  },
  coffee_table(tint) {
    const g = new THREE.Group(), legs = dark();
    cyl(g, 0.45, 0.45, 0.04, tint, 0, 0.38, 0, 40);
    for (let i = 0; i < 3; i++) {
      const a = i * Math.PI * 2 / 3;
      cyl(g, 0.02, 0.02, 0.38, legs, Math.sin(a) * 0.3, 0, Math.cos(a) * 0.3, 10);
    }
    return g;
  },
  floor_lamp(tint) {
    const g = new THREE.Group(), metal = dark();
    cyl(g, 0.16, 0.18, 0.03, metal, 0, 0, 0);
    cyl(g, 0.012, 0.012, 1.45, metal, 0, 0.03, 0, 10);
    const shade = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.24, 0.3, 32, 1, true), tint);
    shade.material.side = THREE.DoubleSide; shade.material.emissive = new THREE.Color('#ffd99a'); shade.material.emissiveIntensity = 0.25;
    shade.position.y = 1.55; shade.castShadow = true; g.add(shade);
    return g;
  },
  bookshelf(tint) {
    const g = new THREE.Group();
    box(g, 0.04, 1.8, 0.32, tint, -0.43, 0, 0); box(g, 0.04, 1.8, 0.32, tint, 0.43, 0, 0);
    for (let i = 0; i <= 5; i++) box(g, 0.82, 0.03, 0.3, tint, 0, i * 0.35, 0);
    box(g, 0.86, 1.78, 0.012, tint, 0, 0.02, -0.158);
    const cols = ['#c8553d', '#3d6b8c', '#e2b84b', '#5a7a52', '#e8e2d6', '#6b4a7a'];
    for (let r = 0; r < 5; r++) {
      let x = -0.38;
      for (let k = 0; x < 0.36; k++) {
        const w = 0.03 + ((r * 7 + k * 3) % 4) * 0.012, h = 0.2 + ((r * 5 + k * 11) % 5) * 0.02;
        box(g, w, h, 0.2, mat(cols[(r * 3 + k) % cols.length], 0.8), x + w / 2, r * 0.35 + 0.03, 0.02);
        x += w + 0.004;
      }
    }
    return g;
  },
  bed(tint) {
    const g = new THREE.Group(), frame = wood(), sheet = mat('#e8e4dc', 0.95);
    box(g, 1.6, 0.22, 2.0, frame, 0, 0.08, 0);
    box(g, 1.64, 0.9, 0.08, frame, 0, 0.08, -1.0);
    box(g, 1.5, 0.2, 1.9, sheet, 0, 0.3, 0.02);
    box(g, 1.52, 0.04, 1.2, tint, 0, 0.49, 0.38);
    for (const x of [-0.38, 0.38]) box(g, 0.62, 0.12, 0.38, sheet, x, 0.5, -0.7);
    return g;
  },
  plant(tint) {
    const g = new THREE.Group(), leaf = mat('#4f7d4a', 0.8);
    cyl(g, 0.17, 0.12, 0.3, tint, 0, 0, 0);
    for (let i = 0; i < 9; i++) {
      const a = i * 2.4, r = 0.1 + (i % 3) * 0.05;
      ball(g, 0.14 + (i % 2) * 0.04, leaf, Math.sin(a) * r, 0.45 + i * 0.07, Math.cos(a) * r);
    }
    return g;
  }
};

export const CATALOG = [
  { id: 'sofa', name: 'Sofa', color: '#7a8b6f' },
  { id: 'armchair', name: 'Armchair', color: '#b5533c' },
  { id: 'dining_table', name: 'Dining table', color: '#a9784f' },
  { id: 'chair', name: 'Chair', color: '#8a6a4a' },
  { id: 'coffee_table', name: 'Coffee table', color: '#c9b79c' },
  { id: 'bookshelf', name: 'Bookshelf', color: '#8a6a4a' },
  { id: 'bed', name: 'Bed', color: '#3d4a5c' },
  { id: 'floor_lamp', name: 'Floor lamp', color: '#e8e2d6' },
  { id: 'plant', name: 'Plant', color: '#b5533c' }
];

export function buildItem(id, color) {
  const def = CATALOG.find(c => c.id === id);
  const tint = mat(color || def.color, 0.8);
  const g = builders[id](tint);
  g.userData = { id, name: def.name, tint };
  const size = new THREE.Box3().setFromObject(g).getSize(new THREE.Vector3());
  g.userData.dims = size.toArray();
  return g;
}
