# Roomfit – AR furniture placement

A WebXR app: point your phone at the floor, pick a piece of furniture, tap to place it at real-world scale.
No build step, no dependencies to install (three.js is vendored in `/vendor`).

## Deploy on Netlify
1. Go to https://app.netlify.com/drop and drag the unzipped folder (or the zip) onto the page.
   Or: new site → "Deploy manually" → upload the folder.
2. Open the generated `https://….netlify.app` URL **on your phone**. AR requires HTTPS, which Netlify provides.

## Requirements
- AR mode: Chrome (or Samsung Internet) on an ARCore-supported Android phone.
- iPhone/iPad Safari and desktop browsers don't support WebXR AR; the app falls back to an interactive 3D preview.

## Controls
- Pick an item at the bottom, aim the white ring at the floor, tap to place.
- Tap a placed item to select it. Rotate, resize, recolour, Move (then tap a new spot) or Delete.
- Size readout shows real dimensions in cm.

## Add your own models
Furniture is generated in `furniture.js` (units = metres, base on y=0, front faces +Z). Add a builder and a `CATALOG` entry.
